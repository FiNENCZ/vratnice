package cz.diamo.vratnice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import cz.diamo.vratnice.entity.Klic;
import cz.diamo.vratnice.entity.ZadostKlic;

public interface ZadostKlicRepository extends JpaRepository<ZadostKlic, String> {
    static final String sqlSelect = "select s from ZadostKlic s ";

    @Query(sqlSelect + "where s.idZadostKlic = :idZadostKlic")
    ZadostKlic getDetail(String idZadostKlic);

    @Query(sqlSelect + "where s.stav = :stav")
    List<ZadostKlic> getZadostiByStav(String stav);

    @Query(sqlSelect + "where s.klic = :klic")
    List<ZadostKlic> findByKlic(Klic klic);
}
