package cz.diamo.vratnice.enums;

public enum KlicStateEnum {
   AKTIVNI,
   BLOKOVAN

}
